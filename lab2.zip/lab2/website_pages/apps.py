from django.apps import AppConfig


class WebsitePagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'website_pages'
