from django.apps import AppConfig


class FruitsAndStudentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fruits_and_students'
