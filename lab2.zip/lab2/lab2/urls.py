from django.contrib import admin 
from django.urls import path, include
urlpatterns = [
    path("admin/", admin.site.urls),
    path('fruits_and_students/', include('fruits_and_students.urls')), #lab 2.1
    path('', include('website_pages.urls')), #lab 2.3
    path('registration/', include('course_registration.urls')),#lab 2.3
]