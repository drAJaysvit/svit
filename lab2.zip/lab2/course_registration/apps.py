from django.apps import AppConfig


class CourseRegistrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'course_registration'
