from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100, unique=True)
    date_of_birth = models.DateField(blank=False, null=False)
    email = models.EmailField(blank=False, null=False)
    
    def __str__(self):
        return self.name

class Course(models.Model):
    name = models.CharField(max_length=100, unique=True)
    students = models.ManyToManyField(Student, related_name='courses')
    course_id = models.IntegerField(unique=True)
    
    def __str__(self):
        return self.name