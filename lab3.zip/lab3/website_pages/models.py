from django.db import models 

class Student(models.Model):

    first_name = models.CharField(max_length=100) 
    last_name = models.CharField(max_length=100) 
    email = models.EmailField()
    enrolled_courses = models.ManyToManyField('Course', related_name='students')

    def  str (self):

        return f"{self.first_name} {self.last_name}"



class Course(models.Model):

    name = models.CharField(max_length=100) 
    description = models.TextField() 
    start_date = models.DateField() 
    end_date = models.DateField()
    def  str (self): 
        return self.name

